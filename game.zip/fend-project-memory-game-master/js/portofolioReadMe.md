#  My Portfolio
 Gives a clear introduction to the world of programming. It expalins about internet, website and broadband.
### Table of contents:
  - [Internet](https://www.google.ca/search?rlz=1C1CHBF_enCA783CA783&q=Internet&stick=H4sIAAAAAAAAAONgFuLQz9U3sDCyKFMCs4yLckq0-Jzzc3Pz84IzU1LLEyuLAWK6XbEmAAAA&sa=X&ved=0ahUKEwilj5jhxMbZAhVq6YMKHeZtAnkQxA0I5wEwEw&biw=1920&bih=888)
   ![internet](https://www.cigionline.org/sites/default/files/styles/slideshow/public/images/landscape/stock-internet.jpg?itok=w4Hdm6bI)
    
  - [Website](https://www.google.ca/search?sa=X&rlz=1C1CHBF_enCA783CA783&biw=1920&bih=888&q=website&stick=H4sIAAAAAAAAAONgFuLQz9U3sDCyKFOCsEzzTLT4nPNzc_PzgjNTUssTK4sBDkiL3CYAAAA&npsic=0&ved=0ahUKEwjS8oP0xMbZAhUU84MKHU1OBXoQ-BYIJw)
    
 - [Broadband](https://www.google.ca/search?sa=X&rlz=1C1CHBF_enCA783CA783&biw=1920&bih=888&q=Broadband&stick=H4sIAAAAAAAAAONgFuLQz9U3KMiqKFPiBLEMjUosTbT4nPNzc_PzgjNTUssTK4sBfUW39icAAAA&npsic=0&ved=0ahUKEwj6l4f818bZAhWCy4MKHaW7CZgQ-BYIMA)
  

### Overview
Information about various computer programming fields can be obtained from the site. User neds to click on the images in **Featured Info** and links under those images to get acces to the above written links.

### Type of App
It is a website, that can be viewed live in various web browsers like **Chrome, Firefox** etc. User needs to type in the link to the site.
### Information about HTML
HTML to the site is quite simple with a linked design sheet as shown below
````html
 <link href="css\styles.css" rel="stylesheet">
 ````
 **Here are a few things included in CSS:**

- Choose colors of everything on the page like the background, font, or main menu.

- Set the size of any element such as font size, width of the entire site, or an image

- Change the state of items when hovering over them

- For example:
````css
.display {
    width: 250px;
    height: 150px;
    overflow: hidden;
    margin: auto;
}
````
### How to use:
- Open the page and click on any of the small pictures to open the licks 
- Read and achieve your required information.



